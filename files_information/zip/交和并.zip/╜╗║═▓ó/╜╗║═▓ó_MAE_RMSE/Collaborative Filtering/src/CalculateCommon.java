/**
 * 计算用户之间交集
 * 
 * @author Administrator
 *
 */
public class CalculateCommon implements Base {

	//实现方法
	public static int calculateUserCommon (int userIdOne, int userIdTwo, int[][] user_movie_base) {
		int[] userOneMovie = user_movie_base[userIdOne];
		int[] userTwoMovie = user_movie_base[userIdTwo];
		int commonNum = 0;
		for (int i = 0; i < COLUMNCOUNT; i++) {
			if (userOneMovie[i] != 0 || userTwoMovie[i] != 0) {
				commonNum++;
			}
		}
		return commonNum;
	}

	//计算交集/并集
	public static double calculateJiaoAndBin(int userIdOne, int userIdTwo, int[][] user_movie_base) {

		//1、交集计算
		int commonNum = calculateUserCommon(userIdOne, userIdTwo, user_movie_base);

		//2、并集计算
		double differentNum = 0;
		int[] userOneMovie = user_movie_base[userIdOne];
		int[] userTwoMovie = user_movie_base[userIdTwo];
		for (int i = 0; i < COLUMNCOUNT; i++) {
			if (userOneMovie[i] != 0) {
				differentNum++;
			}
			if (userTwoMovie[i] != 0) {
				differentNum++;
			}
		}
		double data = differentNum - commonNum;
		if (data == 0) {
			return 1;
		}
		return commonNum / data;
	}
}
